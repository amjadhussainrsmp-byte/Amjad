# Adabi Library — Digital Literary Archive

Starter foundation for a multilingual literary digital library.

## Included in this first build

- Next.js + TypeScript
- English / Hindi / Urdu routes
- Urdu RTL foundation
- Responsive homepage
- Books, poetry, authors and research sections
- Search route foundation
- PostgreSQL/Prisma data model for Authors, Books, Poems, Articles and Tags
- Scalable content-status workflow

## Run locally

```bash
npm install
cp .env.example .env
# Add your PostgreSQL DATABASE_URL to .env
npm run dev
```

Open http://localhost:3000

## Next modules

1. Prisma database connection and seed data
2. Full admin CMS
3. Authentication and roles
4. Book upload + secure digital reader
5. Poetry/author CRUD
6. Full multilingual content editor
7. Advanced search and filters
8. Bookmarks/favourites
9. Manuscript archive
10. SEO, sitemap and production deployment
