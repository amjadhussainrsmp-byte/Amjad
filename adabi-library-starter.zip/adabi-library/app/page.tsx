import Link from "next/link";
import { Search, ArrowRight } from "lucide-react";

const books = [
  {title:"Bihar Aur Sufivad", author:"Syed Amjad Hussain", meta:"Hindi · Research", tags:["Sufism","History"]},
  {title:"Selected Urdu Poetry", author:"Literary Collection", meta:"Urdu · Poetry", tags:["Ghazal","Sher"]},
  {title:"Sufi Heritage of Bihar", author:"Digital Archive", meta:"English · History", tags:["Heritage","Research"]},
  {title:"Classical Naat Collection", author:"Archive Collection", meta:"Urdu · Naat", tags:["Naat","Poetry"]}
];

const authors = [
  ["میر تقی میر","Mir Taqi Mir","م"],
  ["مرزا غالب","Mirza Ghalib","غ"],
  ["امیر خسرو","Amir Khusrau","خ"],
  ["بہار کے اہلِ قلم","Bihar Literary Archive","ب"]
];

export default function Home(){
 return <main>
  <header className="topbar">
   <div className="container nav">
    <Link href="/" className="logo">Adabi<span>Library</span></Link>
    <nav className="navlinks"><Link href="#books">Books</Link><Link href="#poetry">Poetry</Link><Link href="#authors">Authors</Link><Link href="#articles">Articles</Link><Link href="#heritage">Heritage</Link></nav>
    <div className="lang"><Link className="active" href="/">EN</Link><Link href="/hi">हि</Link><Link href="/ur">اردو</Link></div>
   </div>
  </header>

  <section className="hero">
   <div className="container">
    <div className="eyebrow">Digital Literary Archive</div>
    <h1>Discover books, poetry, authors and literary heritage.</h1>
    <p>A multilingual digital library bringing literature, research, poetry and cultural heritage together in one searchable archive.</p>
    <form className="search" action="/search">
      <Search size={20} style={{margin:"14px 5px 14px 12px"}}/>
      <input name="q" placeholder="Search books, poems, authors, sher & articles" />
      <button>Search</button>
    </form>
   </div>
  </section>

  <section className="section" id="books">
   <div className="container">
    <div className="sectionhead"><div><div className="eyebrow">Library</div><h2>Featured Books</h2></div><Link href="/books" className="muted">View all <ArrowRight size={14}/></Link></div>
    <div className="grid">{books.map(b=><article className="card" key={b.title}><div className="cover">{b.title}</div><div className="cardbody"><h3 className="cardtitle">{b.title}</h3><div className="meta">{b.author} · {b.meta}</div><div className="tags">{b.tags.map(t=><span className="tag" key={t}>{t}</span>)}</div></div></article>)}</div>
   </div>
  </section>

  <section className="section poetry" id="poetry">
   <div className="container">
    <div className="sectionhead"><div><div className="eyebrow">Poetry Archive</div><h2>Featured Poetry</h2><div className="muted">Ghazal · Nazm · Naat · Manqabat · Sher</div></div></div>
    <div className="poemgrid">
      <article className="poem"><h3>غزل</h3><div className="poemtext">دل ہی تو ہے نہ سنگ و خشت، درد سے بھر نہ آئے کیوں<br/>روئیں گے ہم ہزار بار، کوئی ہمیں ستائے کیوں</div><div className="meta" style={{marginTop:15}}>— Mirza Ghalib</div></article>
      <article className="poem"><h3>Sher</h3><div className="poemtext">پتّا پتّا، بوٹا بوٹا حال ہمارا جانے ہے<br/>جانے نہ جانے گل ہی نہ جانے، باغ تو سارا جانے ہے</div><div className="meta" style={{marginTop:15}}>— Mir Taqi Mir</div></article>
      <article className="poem"><h3>Naat</h3><div className="poemtext">A curated collection of classical and contemporary naat literature.</div><div className="meta" style={{marginTop:15}}>— Literary Archive</div></article>
    </div>
   </div>
  </section>

  <section className="section" id="authors">
   <div className="container">
    <div className="sectionhead"><div><div className="eyebrow">People</div><h2>Authors & Poets</h2></div></div>
    <div className="authorgrid">{authors.map(a=><article className="author" key={a[0]}><div className="avatar">{a[2]}</div><h3 className="cardtitle">{a[0]}</h3><div className="meta">{a[1]}</div></article>)}</div>
   </div>
  </section>

  <section className="section" id="articles">
   <div className="container">
    <div className="sectionhead"><div><div className="eyebrow">Research</div><h2>Articles & Research</h2></div></div>
    <div className="grid">
      {["Bihar mein Sufivad ki riwayat","Urdu literature and its cultural heritage","Reading and preserving historical manuscripts","Poetry as an archive of memory"].map((x,i)=><article className="card" key={x}><div className="cardbody"><div className="meta">RESEARCH · 2026</div><h3 className="cardtitle" style={{marginTop:8}}>{x}</h3><p className="muted">Explore essays, research and archival material from the literary collection.</p></div></article>)}
    </div>
   </div>
  </section>

  <footer className="footer" id="heritage">
   <div className="container footergrid">
    <div><div className="logo">Adabi<span>Library</span></div><p>A digital home for books, poetry, literature, research and cultural heritage.</p></div>
    <div><h3>Explore</h3><p><Link href="/books">Books</Link><br/><Link href="/poetry">Poetry</Link><br/><Link href="/authors">Authors</Link></p></div>
    <div><h3>Archive</h3><p>Manuscripts<br/>Sufi Literature<br/>Research<br/>Heritage</p></div>
    <div><h3>Information</h3><p>About<br/>Copyright<br/>Privacy<br/>Contact</p></div>
   </div>
  </footer>
 </main>
}