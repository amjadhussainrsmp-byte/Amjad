import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Adabi Library — Digital Literary Archive",
  description: "A multilingual digital library for books, poetry, authors, literature and heritage.",
};

export default function RootLayout({children}:{children:React.ReactNode}) {
  return <>{children}</>;
}