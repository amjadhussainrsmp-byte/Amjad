# Adabi Library — Phase 2

Adds the database-backed CMS foundation:
- Prisma/PostgreSQL schema
- API routes for Authors, Books, Poems and Articles
- Admin dashboard with live database counts
- Admin catalogue pages
- Draft/Review/Published workflow fields

Setup:
1. npm install
2. cp .env.example .env
3. Add PostgreSQL DATABASE_URL
4. npx prisma generate
5. npx prisma migrate dev --name init
6. npm run dev
7. Open /admin
