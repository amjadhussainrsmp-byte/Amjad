import { prisma } from "@/lib/prisma";
export default async function Admin(){
 const [books,authors,poems,articles]=await Promise.all([
  prisma.book.count(),prisma.author.count(),prisma.poem.count(),prisma.article.count()
 ]);
 const stats=[["Books",books],["Authors & Poets",authors],["Poetry",poems],["Articles",articles]];
 return <div><div className="admin-head"><div><div className="eyebrow">Administration</div><h1>Dashboard</h1></div></div>
 <div className="statgrid">{stats.map(s=><div className="stat" key={s[0]}><div className="statnum">{s[1]}</div><div>{s[0]}</div></div>)}</div>
 <div className="panel"><h2>Content workflow</h2><p>New material can be created as Draft, reviewed, and published after editorial approval. The same multilingual content model is used across books, authors, poetry and articles.</p></div>
 </div>
}