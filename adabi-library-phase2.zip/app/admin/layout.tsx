import Link from "next/link";
import "../globals.css";
export default function AdminLayout({children}:{children:React.ReactNode}){
 return <div className="admin-shell">
  <aside className="sidebar">
   <div className="admin-logo">Adabi<span>Library</span></div>
   <div className="admin-label">CONTENT MANAGEMENT</div>
   <nav>
    <Link href="/admin">Dashboard</Link>
    <Link href="/admin/books">Books</Link>
    <Link href="/admin/authors">Authors & Poets</Link>
    <Link href="/admin/poems">Poetry</Link>
    <Link href="/admin/articles">Articles</Link>
   </nav>
   <div className="admin-label">SYSTEM</div>
   <nav><Link href="/">View Website</Link></nav>
  </aside>
  <main className="admin-main">{children}</main>
 </div>
}