import { prisma } from "@/lib/prisma";
export default async function ArticlesAdmin(){
 const articles=await prisma.article.findMany({include:{author:true},orderBy:{createdAt:"desc"}});
 return <div><div className="admin-head"><div><div className="eyebrow">Research</div><h1>Articles</h1></div><a className="admin-button" href="#new">+ Add Article</a></div>
 <div className="panel tablewrap"><table><thead><tr><th>Title</th><th>Category</th><th>Author</th><th>Status</th></tr></thead><tbody>
 {articles.map(a=><tr key={a.id}><td>{a.titleEn||a.titleHi||a.titleUr}</td><td>{a.category}</td><td>{a.author?.nameEn||a.author?.nameHi||a.author?.nameUr||"—"}</td><td><span className="status">{a.status}</span></td></tr>)}
 </tbody></table>{articles.length===0&&<p className="muted">No articles yet.</p>}</div></div>
}