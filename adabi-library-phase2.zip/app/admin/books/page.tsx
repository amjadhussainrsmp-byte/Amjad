import { prisma } from "@/lib/prisma";
export default async function BooksAdmin(){
 const books=await prisma.book.findMany({include:{author:true},orderBy:{createdAt:"desc"}});
 return <div><div className="admin-head"><div><div className="eyebrow">Content</div><h1>Books</h1></div><a className="admin-button" href="#new">+ Add Book</a></div>
 <div className="panel tablewrap"><table><thead><tr><th>Title</th><th>Author</th><th>Language</th><th>Status</th><th>Year</th></tr></thead><tbody>
 {books.map(b=><tr key={b.id}><td>{b.titleEn||b.titleHi||b.titleUr}</td><td>{b.author?.nameEn||b.author?.nameHi||b.author?.nameUr||"—"}</td><td>{b.language}</td><td><span className="status">{b.status}</span></td><td>{b.year||"—"}</td></tr>)}
 </tbody></table>{books.length===0&&<p className="muted">No books yet. Use the API or the next CMS form module to add content.</p>}</div>
 </div>
}