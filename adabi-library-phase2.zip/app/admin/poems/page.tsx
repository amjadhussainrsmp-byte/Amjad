import { prisma } from "@/lib/prisma";
export default async function PoemsAdmin(){
 const poems=await prisma.poem.findMany({include:{author:true},orderBy:{createdAt:"desc"}});
 return <div><div className="admin-head"><div><div className="eyebrow">Poetry Archive</div><h1>Poetry</h1></div><a className="admin-button" href="#new">+ Add Poem</a></div>
 <div className="panel tablewrap"><table><thead><tr><th>Title</th><th>Genre</th><th>Author</th><th>Language</th><th>Status</th></tr></thead><tbody>
 {poems.map(p=><tr key={p.id}><td>{p.titleEn||p.titleHi||p.titleUr}</td><td>{p.genre}</td><td>{p.author?.nameEn||p.author?.nameHi||p.author?.nameUr||"—"}</td><td>{p.language}</td><td><span className="status">{p.status}</span></td></tr>)}
 </tbody></table>{poems.length===0&&<p className="muted">No poetry entries yet.</p>}</div></div>
}