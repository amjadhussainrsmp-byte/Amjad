import { prisma } from "@/lib/prisma";
export default async function AuthorsAdmin(){
 const authors=await prisma.author.findMany({include:{_count:{select:{books:true,poems:true,articles:true}}},orderBy:{createdAt:"desc"}});
 return <div><div className="admin-head"><div><div className="eyebrow">People</div><h1>Authors & Poets</h1></div><a className="admin-button" href="#new">+ Add Author</a></div>
 <div className="panel tablewrap"><table><thead><tr><th>Name</th><th>Books</th><th>Poems</th><th>Articles</th></tr></thead><tbody>
 {authors.map(a=><tr key={a.id}><td>{a.nameEn||a.nameHi||a.nameUr}</td><td>{a._count.books}</td><td>{a._count.poems}</td><td>{a._count.articles}</td></tr>)}
 </tbody></table>{authors.length===0&&<p className="muted">No authors yet.</p>}</div></div>
}