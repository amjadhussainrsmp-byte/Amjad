import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { slugify } from "@/lib/slug";

export async function GET(){
  const data=await prisma.poem.findMany({orderBy:{createdAt:"desc"},include:{author:true}});
  return NextResponse.json(data);
}
export async function POST(req:Request){
  const b=await req.json();
  const base=b.slug||b.titleEn||b.titleHi||b.titleUr;
  if(!base||!b.language||!b.genre) return NextResponse.json({error:"Title, language and genre are required"},{status:400});
  const data=await prisma.poem.create({data:{
    titleEn:b.titleEn||null,titleHi:b.titleHi||null,titleUr:b.titleUr||null,slug:slugify(base),
    textEn:b.textEn||null,textHi:b.textHi||null,textUr:b.textUr||null,genre:b.genre,language:b.language,
    status:b.status||"DRAFT",authorId:b.authorId||null
  }});
  return NextResponse.json(data,{status:201});
}