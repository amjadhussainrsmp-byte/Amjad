import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { slugify } from "@/lib/slug";

export async function GET(){
  const data=await prisma.book.findMany({orderBy:{createdAt:"desc"},include:{author:true}});
  return NextResponse.json(data);
}
export async function POST(req:Request){
  const b=await req.json();
  const base=b.slug||b.titleEn||b.titleHi||b.titleUr;
  if(!base||!b.language) return NextResponse.json({error:"Title and language are required"},{status:400});
  const data=await prisma.book.create({data:{
    titleEn:b.titleEn||null,titleHi:b.titleHi||null,titleUr:b.titleUr||null,slug:slugify(base),
    descriptionEn:b.descriptionEn||null,descriptionHi:b.descriptionHi||null,descriptionUr:b.descriptionUr||null,
    language:b.language,year:b.year?Number(b.year):null,publisher:b.publisher||null,pages:b.pages?Number(b.pages):null,
    coverUrl:b.coverUrl||null,fileUrl:b.fileUrl||null,status:b.status||"DRAFT",authorId:b.authorId||null
  }});
  return NextResponse.json(data,{status:201});
}