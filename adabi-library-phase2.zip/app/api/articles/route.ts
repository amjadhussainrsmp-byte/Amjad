import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { slugify } from "@/lib/slug";

export async function GET(){
  const data=await prisma.article.findMany({orderBy:{createdAt:"desc"},include:{author:true}});
  return NextResponse.json(data);
}
export async function POST(req:Request){
  const b=await req.json();
  const base=b.slug||b.titleEn||b.titleHi||b.titleUr;
  if(!base||!b.category) return NextResponse.json({error:"Title and category are required"},{status:400});
  const data=await prisma.article.create({data:{
    titleEn:b.titleEn||null,titleHi:b.titleHi||null,titleUr:b.titleUr||null,slug:slugify(base),
    bodyEn:b.bodyEn||null,bodyHi:b.bodyHi||null,bodyUr:b.bodyUr||null,category:b.category,
    status:b.status||"DRAFT",authorId:b.authorId||null
  }});
  return NextResponse.json(data,{status:201});
}