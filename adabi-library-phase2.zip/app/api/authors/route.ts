import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { slugify } from "@/lib/slug";

export async function GET(){
  const data=await prisma.author.findMany({orderBy:{createdAt:"desc"},include:{_count:{select:{books:true,poems:true,articles:true}}}});
  return NextResponse.json(data);
}
export async function POST(req:Request){
  const body=await req.json();
  const base=body.slug || body.nameEn || body.nameHi || body.nameUr;
  if(!base) return NextResponse.json({error:"Author name is required"},{status:400});
  const data=await prisma.author.create({data:{
    nameEn:body.nameEn||null,nameHi:body.nameHi||null,nameUr:body.nameUr||null,
    slug:slugify(base),bioEn:body.bioEn||null,bioHi:body.bioHi||null,bioUr:body.bioUr||null,imageUrl:body.imageUrl||null
  }});
  return NextResponse.json(data,{status:201});
}