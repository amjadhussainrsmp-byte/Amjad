import { SignJWT, jwtVerify } from "jose";
import bcrypt from "bcryptjs";
import { cookies } from "next/headers";
import { prisma } from "./prisma";

const secret=new TextEncoder().encode(process.env.AUTH_SECRET||"CHANGE_THIS_SECRET_IN_PRODUCTION");

export async function hashPassword(p:string){return bcrypt.hash(p,12)}
export async function verifyPassword(p:string,h:string){return bcrypt.compare(p,h)}

export async function createSession(adminId:string){
 const token=await new SignJWT({adminId}).setProtectedHeader({alg:"HS256"}).setIssuedAt().setExpirationTime("7d").sign(secret);
 cookies().set("adabi_session",token,{httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"lax",path:"/",maxAge:60*60*24*7});
}
export async function getAdmin(){
 try{
  const token=cookies().get("adabi_session")?.value;
  if(!token)return null;
  const {payload}=await jwtVerify(token,secret);
  if(typeof payload.adminId!=="string")return null;
  return prisma.admin.findUnique({where:{id:payload.adminId}});
 }catch{return null}
}
export function clearSession(){cookies().delete("adabi_session")}
