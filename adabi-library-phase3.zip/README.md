# Adabi Library — Phase 3

Adds:
- Secure password hashing
- JWT-based HTTP-only admin session cookie
- Admin login at /login
- Protected /admin routes
- Logout API
- Create/update/delete API foundations
- Working Book create/edit form with EN/HI/UR fields
- Content status workflow
- PostgreSQL/Prisma integration

Setup:
npm install
cp .env.example .env
npx prisma generate
npx prisma migrate dev --name phase3

For first admin only, temporarily set ALLOW_ADMIN_SEED=true, then POST JSON to /api/admin/seed:
{"name":"Admin","email":"admin@example.com","password":"a-strong-password"}

Set ALLOW_ADMIN_SEED=false immediately afterwards.
Then open /login.

Production note:
Use a strong AUTH_SECRET, HTTPS, managed object storage for PDFs/images, and a proper rate limiter/WAF before public deployment.
