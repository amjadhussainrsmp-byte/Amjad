 "use client";
import {useState} from "react"; import {useRouter} from "next/navigation";
export default function Login(){
 const [email,setEmail]=useState("");const [password,setPassword]=useState("");const [error,setError]=useState("");const [loading,setLoading]=useState(false);const router=useRouter();
 async function submit(e:React.FormEvent){e.preventDefault();setLoading(true);setError("");const r=await fetch("/api/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email,password})});const d=await r.json();setLoading(false);if(!r.ok){setError(d.error||"Login failed");return}router.push("/admin")}
 return <main className="login"><form className="loginbox" onSubmit={submit}><div className="admin-logo">Adabi<span>Library</span></div><div className="eyebrow">Administrator</div><h1>Sign in</h1>{error&&<div className="error">{error}</div>}<label>Email<input value={email} onChange={e=>setEmail(e.target.value)} type="email" required/></label><label>Password<input value={password} onChange={e=>setPassword(e.target.value)} type="password" required/></label><button disabled={loading}>{loading?"Signing in…":"Sign in"}</button></form></main>
}