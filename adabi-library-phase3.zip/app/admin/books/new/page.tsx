import BookForm from "@/components/BookForm";
import {prisma} from "@/lib/prisma";
export default async function NewBook(){const authors=await prisma.author.findMany({orderBy:{nameEn:"asc"}});return <div><div className="admin-head"><div><div className="eyebrow">Library</div><h1>Add Book</h1></div></div><BookForm authors={authors}/></div>}