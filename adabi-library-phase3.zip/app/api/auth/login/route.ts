import {NextResponse} from "next/server";
import {prisma} from "@/lib/prisma";
import {verifyPassword,createSession} from "@/lib/auth";

export async function POST(req:Request){
 const {email,password}=await req.json();
 if(!email||!password)return NextResponse.json({error:"Email and password are required"},{status:400});
 const admin=await prisma.admin.findUnique({where:{email:email.toLowerCase().trim()}});
 if(!admin||!(await verifyPassword(password,admin.passwordHash)))return NextResponse.json({error:"Invalid credentials"},{status:401});
 await createSession(admin.id);
 return NextResponse.json({ok:true,admin:{id:admin.id,name:admin.name,email:admin.email,role:admin.role}});
}