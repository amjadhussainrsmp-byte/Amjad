import {NextResponse} from "next/server";
import {prisma} from "@/lib/prisma";
import {hashPassword} from "@/lib/auth";

export async function POST(req:Request){
 if(process.env.ALLOW_ADMIN_SEED!=="true")return NextResponse.json({error:"Admin seed disabled"},{status:403});
 const b=await req.json();
 if(!b.email||!b.password||!b.name)return NextResponse.json({error:"name, email and password required"},{status:400});
 const existing=await prisma.admin.findUnique({where:{email:b.email.toLowerCase()}});
 if(existing)return NextResponse.json({error:"Admin already exists"},{status:409});
 const admin=await prisma.admin.create({data:{name:b.name,email:b.email.toLowerCase(),passwordHash:await hashPassword(b.password),role:"SUPER_ADMIN"}});
 return NextResponse.json({id:admin.id,email:admin.email},{status:201});
}