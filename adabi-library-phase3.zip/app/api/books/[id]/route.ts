import {NextResponse} from "next/server";
import {prisma} from "@/lib/prisma";
import {slugify} from "@/lib/slug";
export async function GET(_:Request,{params}:{params:{id:string}}){
 const x=await prisma.book.findUnique({where:{id:params.id},include:{author:true}});
 return x?NextResponse.json(x):NextResponse.json({error:"Not found"},{status:404});
}
export async function PUT(req:Request,{params}:{params:{id:string}}){
 const b=await req.json(); const base=b.slug||b.titleEn||b.titleHi||b.titleUr;
 try{const x=await prisma.book.update({where:{id:params.id},data:{
  titleEn:b.titleEn??null,titleHi:b.titleHi??null,titleUr:b.titleUr??null,slug:slugify(base),
  descriptionEn:b.descriptionEn??null,descriptionHi:b.descriptionHi??null,descriptionUr:b.descriptionUr??null,
  language:b.language,year:b.year?Number(b.year):null,publisher:b.publisher??null,pages:b.pages?Number(b.pages):null,
  coverUrl:b.coverUrl??null,fileUrl:b.fileUrl??null,status:b.status||"DRAFT",authorId:b.authorId||null
 }});return NextResponse.json(x)}catch{return NextResponse.json({error:"Unable to update book"},{status:400})}
}
export async function DELETE(_:Request,{params}:{params:{id:string}}){
 await prisma.book.delete({where:{id:params.id}});return NextResponse.json({ok:true});
}